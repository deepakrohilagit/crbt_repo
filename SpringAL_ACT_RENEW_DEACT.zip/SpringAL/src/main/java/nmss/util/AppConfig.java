package nmss.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
/* @PropertySource("Config.properties") */
public class AppConfig {

	/*
	 * @Value("#{'${ucip.live.circle}'.split(',')}") public List<String>
	 * liveCircles;
	 */

	@Value("${cdr.server.ip}")
	public String cdr_ip;

	@Value("${cdr.server.port}")
	public int cdr_port;

	@Value("${provisning.server.ip}")
	public String provisningIp;

	@Value("${provisning.server.port}")
	public int provisningPort;

	@Value("${provisning.activate.packet}")
	public String activatePacket;

	@Value("${provisning.deactivate.packet}")
	public String deactivatePacket;

	@Value("${client.token.url}")
	public String tokenUrl;

	@Value("${client.balance.url}")
	public String balanceUrl;

	@Value("${client.debit.url}")
	public String debitUrl;

	@Value("${service.thread.pool.size}")
	public int serviceThreadPoolSize;

	@Value("${fulfilment.request.table}")
	public String fulfilmentRequestTable;

	@Value("${fulfilment.request.select.logic}")
	public String selectRequestLogic;

	@Value("${db.connection.type}")
	public String dbConnectionType;

	@Value("${transaction.tps}")
	public int transactionTps;

	@Value("${response.url.readtimeout}")
	public int responseUrlReadtimeout;

	@Value("${response.url.connecttimeOut}")
	public int responseUrlConnecttimeout;

	public boolean isPullingFromDB = true;
}
