package nmss.Transactions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;

import nmss.base.Request;
import nmss.base.Transaction;
import nmss.pojos.crbt.CrbtRequest;
import nmss.util.JdbcCrbtRequestDAOImpl;

@Component("end")
@Scope("prototype")
public class End extends Transaction {

	@Autowired
	private Gson gson;

	@Override
	public boolean doTransaction(Request request) {
		try {

			CrbtRequest crbtRequest = (CrbtRequest) request;
			requestDAO.deleteByTid(request.getTid());

			if ("0".equals(request.getTxnStatus())) {
				if ("crbt".equalsIgnoreCase(request.getFlowName())) {
					JdbcCrbtRequestDAOImpl jdbcCrbtRequestDAOImpl = (JdbcCrbtRequestDAOImpl) requestDAO;
					jdbcCrbtRequestDAOImpl.saveAsSubscribe(crbtRequest);
				}else if("renew".equalsIgnoreCase(request.getFlowName())){
					
				}
			}
			// utility.UDP_SEND(appConfig.cdr_ip, appConfig.cdr_port,
			// request.toCdr(), false);

			/* Response URL Curl with JSON */
			/*
			 * VirginResponse virginResponse =
			 * Start.ctx.getBean("virginResponse", VirginResponse.class);
			 * virginResponse.setTid(request.getTid());
			 * virginResponse.setMsisdn(request.getMsisdn()); FmResponse
			 * fmResponse = Start.ctx.getBean("fmResponse", FmResponse.class);
			 * virginResponse.setFmResponse(fmResponse); fmResponse.setCampId(""
			 * + virginRequest.getCampaignParam().getCampId()); if
			 * ("0".equals(request.getTxnStatus())) { String successMsg =
			 * virginRequest.getFulfillment_BenefitParam().getSuccessMsg() ==
			 * null ? appConfig.successSms :
			 * virginRequest.getFulfillment_BenefitParam().getSuccessMsg();
			 * fmResponse.setMsg(successMsg); fmResponse.setResult("Success"); }
			 * else { String failMsg =
			 * virginRequest.getFulfillment_BenefitParam().getFailSms() == null
			 * ? appConfig.failSms :
			 * virginRequest.getFulfillment_BenefitParam().getFailSms();
			 * fmResponse.setMsg(failMsg); fmResponse.setResult("fail"); }
			 */
			// utility.sendPost(virginRequest.getUrl(),
			// gson.toJson(virginResponse), "application/json");
			lFile.info("End : " + request + ", TimeTake:" + request.getRequestTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
