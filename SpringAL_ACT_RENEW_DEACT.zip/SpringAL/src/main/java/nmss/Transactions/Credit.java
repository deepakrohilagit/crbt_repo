package nmss.Transactions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import nmss.base.Request;
import nmss.base.Transaction;
import nmss.util.CrbtClientStub;

@Component("credit")
@Scope("prototype")
public class Credit extends Transaction {

	@Autowired
	private CrbtClientStub crbtClientStub;

	@Override
	public boolean doTransaction(Request request) {
		try {
			crbtClientStub.doCredit(request);

			lFile.info("Credit Result : " + request + ", TimeTake:" + request.getTxnTime());

			requestDAO.updateState(request);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
}
